Read me first:
1.this programm is about menu list.
2.linkNode.c is about the data struct.
3.menu.c contain two function,one is ShowAllCmd,this function is aim to output the menu list 
  when user input the command"help".the other is FindCmd, it can compare the input command and system command.
4.Compiling method
  gcc linkNode.c menu.c test.c - o test
  gcc ./test


