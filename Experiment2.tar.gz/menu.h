/**************************************************************************************************/
/* Copyright (C) 7#1606,SSE@USTC,2014-2015                                                        */
/*                                                                                                */ 
/* FILE NAME             :  experiment2                                                           */
/* PRINCIPAL AUTHOR      :  QuPanpan                                                              */
/* SUBSYSTEM NAME        :  Document                                                              */
/* MODULE NAME           :  menu                                                                  */
/* LANGUAGE              :  C                                                                     */
/* TARGET ENVIRONMENT    :  ANY                                                                   */
/* DATA OF FRIST RELEASE :  2014/09/21                                                            */
/* DESCRIPTION           :  This is the first homework about a menu programm                      */ 
/**************************************************************************************************/
 
/*
 *Revision log:
 *Created by QuPanpan,2014/09/21
 */

#define _MENU_H_
#define SUCCESS 0
#define FAILURE (-1)


typedef struct DataNode  
{    
    char*   cmd;       /*DataNode's data*/
    char*   desc;      /*commmand's description*/
    int     (*handler) (); 
    struct  DataNode *next;/*address*/    
}tDataNode;
/*
*show all command of the menu
*/
static tDataNode head[];
int ShowAllCmd(tDataNode*head);

extern int ShowAllCmd(tDataNode*head);
/*
*comparision input command and system command 
*/
tDataNode* FindCmd(tDataNode *head,char *cmd);

extern tDataNode* FindCmd(tDataNode *head,char *cmd);


