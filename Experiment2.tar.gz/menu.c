/**************************************************************************************************/
/* Copyright (C) 7#1606,SSE@USTC,2014-2015                                                        */
/*                                                                                                */ 
/* FILE NAME             :  experiment2                                                           */
/* PRINCIPAL AUTHOR      :  QuPanpan                                                              */
/* SUBSYSTEM NAME        :  Document                                                              */
/* MODULE NAME           :  menu                                                                  */
/* LANGUAGE              :  C                                                                     */
/* TARGET ENVIRONMENT    :  ANY                                                                   */
/* DATA OF FRIST RELEASE :  2014/09/21                                                            */
/* DESCRIPTION           :  This is the first homework about a menu programm                      */ 
/**************************************************************************************************/
 
/*
 *Revision log:
 *Created by QuPanpan,2014/09/21
 */

#include<stdio.h>
#include<stdlib.h>
#include <pthread.h>
#include"linkNode.h"
#include"menu.h"


int ShowAllCmd(tDataNode*head)
{
    tDataNode *p=head;
    while(p!=NULL)
    {
        printf("%s - %s\n",p->cmd,p->desc);
        p=p->next;    
    } 
}


tDataNode* FindCmd(tDataNode *head,char *cmd)
{
    tDataNode *p=head;
    if(p==NULL || cmd==NULL)
    { 
        return NULL;
    }
   
    while(p!=NULL)
    {
        if(!strcmp(p->cmd,cmd)) 
        {	
            return p;
        }
        p = p->next; 
    } 
        return NULL;
}   
