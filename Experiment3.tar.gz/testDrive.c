/**************************************************************************************************/
/* Copyright (C) 7#1606,SSE@USTC,2014-2015                                                        */
/*                                                                                                */ 
/* FILE NAME             :  experiment3                                                           */
/* PRINCIPAL AUTHOR      :  QuPanpan                                                              */
/* SUBSYSTEM NAME        :  Document                                                              */
/* MODULE NAME           :  menu                                                                  */
/* LANGUAGE              :  C                                                                     */
/* TARGET ENVIRONMENT    :  ANY                                                                   */
/* DATA OF FRIST RELEASE :  2014/09/27                                                            */
/* DESCRIPTION           :  This is the third homework about a menu programm                      */ 
/**************************************************************************************************/
 
/*
 *Revision log:
 *Created by QuPanpan,2014/09/27
 */

#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>
#include"menu.h"
#define debug printf

/*testDriver*/
int results[5] = {1,1,1,1,1};
char * info[5] =
{
    "classExperiment3 test report",
    "Show all commands",
    "Find a command",
    "Delete a command",
    "Add a command"
};
int main()
{   
    tLinkTable *p = CreateLinkTable();
    if(p == NULL)
    {
	debug("Fail \n");
        results[1] = 1;
    }
    tLinkTable *head = NULL;
    tDataNode *tnode = NULL;
    tDataNode *tNode = (tDataNode *)malloc(sizeof(tDataNode)); 

    int show = ShowAllCmd(head);
    if(show == 0)
    {
	debug("Show all commands is successful\n");
        results[2] = 1;
    }
            
    int del = DelOneCmd(head, tNode);
    if(del == 0)
    {
	debug("delate one command is successful\n");
        results[4] = 1;
    }

    int add = AddCmd(head, tNode);
    if(add == 0)
    {
	debug("add is successful\n");
        results[5] = 1;
    }
   
    
    
    /* test report */
    printf("ClassExperimen3 test report\n");	
    int i;
    for(i=1;i<=5;i++)
    {
        if(results[i] == 1)
       {
           printf("Testcase Number %d F - %s\n ",i,info[i]);
       }
    }
}

 


























