gcc -c linkNode.c menu.c testDrive.c -o testDrive
./testDrive
