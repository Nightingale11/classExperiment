/**************************************************************************************************/
/* Copyright (C) 7#1606,SSE@USTC,2014-2015                                                        */
/*                                                                                                */ 
/* FILE NAME             :  experiment2                                                           */
/* PRINCIPAL AUTHOR      :  QuPanpan                                                              */
/* SUBSYSTEM NAME        :  Document                                                              */
/* MODULE NAME           :  menu                                                                  */
/* LANGUAGE              :  C                                                                     */
/* TARGET ENVIRONMENT    :  ANY                                                                   */
/* DATA OF FRIST RELEASE :  2014/09/21                                                            */
/* DESCRIPTION           :  This is the first homework about a menu programm                      */ 
/**************************************************************************************************/
 
/*
 *Revision log:
 *Created by QuPanpan,2014/09/21
 */

#include<stdio.h>
#include<stdlib.h>
#include <pthread.h>
#include"linkNode.h"
#include"menu.h"

/*Stub1-ShowAllCmd*/
int ShowAllCmd(tLinkTable *head)
{
    if(head == NULL )
	{
	    return 0;
	}
	else
	{
	    return 1;
	}
}

/*Stub2-FindCmd*/
tDataNode* FindCmd(tLinkTable *head,char *cmd)
{
    
}   
/*Stub3-delete one command */
int DelOneCmd(tLinkTable * head, tDataNode *tNode)
{
    if(head == NULL || tNode == NULL)
    {
	return 0;
    }
    else
    {
	return 1;
    }
}

/* Stub4-add one command into the system */
int AddCmd(tLinkTable * head, tDataNode * tNode)
{
    if(head == NULL || tNode == NULL)
    {
        return 0;
    }
    else
    {
        return 1;
    }
}

