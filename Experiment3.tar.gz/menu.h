/**************************************************************************************************/
/* Copyright (C) 7#1606,SSE@USTC,2014-2015                                                        */
/*                                                                                                */ 
/* FILE NAME             :  experiment3                                                           */
/* PRINCIPAL AUTHOR      :  QuPanpan                                                              */
/* SUBSYSTEM NAME        :  Document                                                              */
/* MODULE NAME           :  menu                                                                  */
/* LANGUAGE              :  C                                                                     */
/* TARGET ENVIRONMENT    :  ANY                                                                   */
/* DATA OF FRIST RELEASE :  2014/09/27                                                            */
/* DESCRIPTION           :  This is the third homework about a menu programm                      */ 
/**************************************************************************************************/
 
/*
 *Revision log:
 *Created by QuPanpan,2014/09/27
 */
#include "linkNode.h"

typedef struct DataNode  
{    
    tLinkTableNode  *pNext;
    char*           cmd;               /*DataNode's data*/
    char*           desc;              /*commmand's description*/
    int             (*handler) ();  
}tDataNode;

/*show all command of the menu*/
int ShowAllCmd(tLinkTable *head);

/*comparision input command and system command */
tDataNode* FindCmd(tLinkTable *head,char *cmd);

/* add one command into the system */
int AddCmd(tLinkTable * head, tDataNode *tNode);

/* delete one command into system*/
int DelOneCmd(tLinkTable * head, tDataNode *tNode);


 


