/**************************************************************************************************/
/* Copyright (C) 7#1606,SSE@USTC,2014-2015                                                        */
/*                                                                                                */ 
/* FILE NAME             :  experiment3                                                           */
/* PRINCIPAL AUTHOR      :  QuPanpan                                                              */
/* SUBSYSTEM NAME        :  Document                                                              */
/* MODULE NAME           :  menu                                                                  */
/* LANGUAGE              :  C                                                                     */
/* TARGET ENVIRONMENT    :  ANY                                                                   */
/* DATA OF FRIST RELEASE :  2014/09/27                                                            */
/* DESCRIPTION           :  This is the third homework about a menu programm                      */ 
/**************************************************************************************************/
 
/*
 *Revision log:
 *Created by QuPanpan,2014/09/27
 */

#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>
#include"menu.h"
#include"linkNode.h"
#define  debug
int Help();
/*testDriver*/
int results[3] = {1,1,1};
char * info[3] =
{
    "classExperiment3 test report",
    "Show all command",
    "Find command"
};
int main()
{   
    tLinkTable *p = CreateLinkTable();
    int ret = AddLinkTableNode(p,pNode);
    int show = ShowAllCmd(tLinkTable *head);
    if(show==0)
    {
        debug("we can show all the command of the menu\n");
    }else
    {
        debug("wrong\n");
        results[2] = 0;       
    }
    tDataNode* find = tDataNode* FindCmd(tLinkTable *head,char *cmd)
    if(find == NULL)
    {
        debug("The system can't find the commnd");
        results[3]=0;
    }
    /* test report */
    printf("ClassExperimen3 test report\n");	
    int i;
    for(i=1;i<=2;i++)
    {
        if(results[i] == 1)
        {
            printf("Testcase Number%d F - %s\n",i,info[i]);
        }
    }
}

 


























